import React, { Component } from 'react';
import { Mail, Lock, Eye, EyeOff, ArrowLeft } from 'lucide-react';
import CommonLayout from './CommonLayout';

class ForgotPasswordPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      // 1단계: 코드 요청
      email: '',
      
      // 2단계: 비밀번호 변경
      confirmationCode: '',
      newPassword: '',
      confirmPassword: '',
      showNewPassword: false,
      showConfirmPassword: false,
      
      // UI 상태
      currentStep: 1, // 1: 코드 요청, 2: 비밀번호 변경
      isLoading: false,
      error: null,
      success: null
    };
  }

  handleInputChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value, error: null });
  };

  togglePasswordVisibility = (field) => {
    this.setState(prevState => ({ 
      [field]: !prevState[field] 
    }));
  };

  validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  validatePassword = (password) => {
    // Cognito 기본 비밀번호 정책
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[^A-Za-z0-9]/.test(password);

    return password.length >= minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar;
  };

  handleRequestCode = async (e) => {
    e.preventDefault();
    
    const { email } = this.state;
    
    if (!email) {
      this.setState({ error: '이메일을 입력해주세요.' });
      return;
    }

    if (!this.validateEmail(email)) {
      this.setState({ error: '유효한 이메일 형식을 입력해주세요.' });
      return;
    }

    this.setState({ isLoading: true, error: null });

    try {
      const response = await fetch('http://localhost:8081/api/v1/auth/forgot-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email })
      });

      const data = await response.json();

      if (data.success) {
        this.setState({
          success: data.message,
          currentStep: 2,
          isLoading: false
        });
      } else {
        this.setState({
          error: data.message,
          isLoading: false
        });
      }
    } catch (error) {
      console.error('비밀번호 찾기 오류:', error);
      this.setState({
        error: '네트워크 오류가 발생했습니다.',
        isLoading: false
      });
    }
  };

  handleResetPassword = async (e) => {
    e.preventDefault();
    
    const { email, confirmationCode, newPassword, confirmPassword } = this.state;
    
    if (!confirmationCode || !newPassword || !confirmPassword) {
      this.setState({ error: '모든 필드를 입력해주세요.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      this.setState({ error: '비밀번호가 일치하지 않습니다.' });
      return;
    }

    if (!this.validatePassword(newPassword)) {
      this.setState({ 
        error: '비밀번호는 최소 8자 이상이며, 대문자, 소문자, 숫자, 특수문자를 포함해야 합니다.' 
      });
      return;
    }

    this.setState({ isLoading: true, error: null });

    try {
      const response = await fetch('http://localhost:8081/api/v1/auth/confirm-forgot-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          confirmation_code: confirmationCode,
          new_password: newPassword
        })
      });

      const data = await response.json();

      if (data.success) {
        this.setState({
          success: data.message,
          isLoading: false
        });
        
        // 3초 후 로그인 페이지로 이동
        setTimeout(() => {
          this.props.navigate('/login');
        }, 3000);
      } else {
        this.setState({
          error: data.message,
          isLoading: false
        });
      }
    } catch (error) {
      console.error('비밀번호 재설정 오류:', error);
      this.setState({
        error: '네트워크 오류가 발생했습니다.',
        isLoading: false
      });
    }
  };

  goBackToStep1 = () => {
    this.setState({
      currentStep: 1,
      confirmationCode: '',
      newPassword: '',
      confirmPassword: '',
      error: null,
      success: null
    });
  };

  renderStep1() {
    const { email, isLoading, error } = this.state;

    return (
      <div className="auth-container">
        <div className="auth-header">
          <h1 className="auth-title">비밀번호 찾기</h1>
          <p className="auth-subtitle">가입한 이메일 주소를 입력하시면 인증 코드를 보내드립니다.</p>
        </div>

        {error && (
          <div className="error-message">
            {error}
          </div>
        )}

        <form className="auth-form" onSubmit={this.handleRequestCode}>
          <div className="form-group">
            <label className="form-label">
              <Mail size={16} />
              이메일 주소
            </label>
            <input
              type="email"
              name="email"
              value={email}
              onChange={this.handleInputChange}
              className="form-input"
              placeholder="example@email.com"
              required
            />
          </div>

          <button 
            type="submit"
            className="auth-button" 
            disabled={isLoading}
          >
            {isLoading ? '전송 중...' : '인증 코드 받기'}
          </button>
        </form>

        <div className="auth-footer">
          <button
            onClick={() => this.props.navigate('/login')}
            className="auth-link"
          >
            <ArrowLeft size={16} />
            로그인으로 돌아가기
          </button>
        </div>
      </div>
    );
  }

  renderStep2() {
    const { 
      email, 
      confirmationCode, 
      newPassword, 
      confirmPassword, 
      showNewPassword, 
      showConfirmPassword,
      isLoading, 
      error, 
      success 
    } = this.state;

    return (
      <div className="auth-container">
        <div className="auth-header">
          <h1 className="auth-title">새 비밀번호 설정</h1>
          <p className="auth-subtitle">
            {email}로 전송된 인증 코드를 입력하고 새 비밀번호를 설정하세요.
          </p>
        </div>

        {error && (
          <div className="error-message">
            {error}
          </div>
        )}

        {success && (
          <div className="success-message">
            {success}
          </div>
        )}

        <form className="auth-form" onSubmit={this.handleResetPassword}>
          <div className="form-group">
            <label className="form-label">
              인증 코드
            </label>
            <input
              type="text"
              name="confirmationCode"
              value={confirmationCode}
              onChange={this.handleInputChange}
              className="form-input"
              placeholder="6자리 인증 코드를 입력하세요"
              maxLength="6"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">
              <Lock size={16} />
              새 비밀번호
            </label>
            <div className="password-input-container">
              <input
                type={showNewPassword ? 'text' : 'password'}
                name="newPassword"
                value={newPassword}
                onChange={this.handleInputChange}
                className="form-input"
                placeholder="새 비밀번호를 입력하세요"
                required
              />
              <button
                type="button"
                className="password-toggle"
                onClick={() => this.togglePasswordVisibility('showNewPassword')}
              >
                {showNewPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
            <small className="form-help">
              최소 8자 이상, 대문자, 소문자, 숫자, 특수문자 포함
            </small>
          </div>

          <div className="form-group">
            <label className="form-label">
              <Lock size={16} />
              새 비밀번호 확인
            </label>
            <div className="password-input-container">
              <input
                type={showConfirmPassword ? 'text' : 'password'}
                name="confirmPassword"
                value={confirmPassword}
                onChange={this.handleInputChange}
                className="form-input"
                placeholder="새 비밀번호를 다시 입력하세요"
                required
              />
              <button
                type="button"
                className="password-toggle"
                onClick={() => this.togglePasswordVisibility('showConfirmPassword')}
              >
                {showConfirmPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <button 
            type="submit"
            className="auth-button" 
            disabled={isLoading}
          >
            {isLoading ? '변경 중...' : '비밀번호 변경'}
          </button>
        </form>

        <div className="auth-footer">
          <button
            onClick={this.goBackToStep1}
            className="auth-link"
          >
            <ArrowLeft size={16} />
            이메일 다시 입력하기
          </button>
        </div>
      </div>
    );
  }

  render() {
    return (
      <CommonLayout
        isLoggedIn={false}
        currentUser={null}
        navigate={this.props.navigate}
      >
        <div className="auth-page">
          {this.state.currentStep === 1 ? this.renderStep1() : this.renderStep2()}
        </div>
      </CommonLayout>
    );
  }
}

export default ForgotPasswordPage;
